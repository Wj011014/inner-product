package Ours;

import com.sun.xml.internal.bind.v2.model.core.ID;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;
import static java.lang.System.setOut;


public class Ours {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element  alpha = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  beta = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  gamma = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  u = bp.getG1().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  h = bp.getG1().newRandomElement().getImmutable();//从Zq上任选一个数
        Element[] rho=new Element[n];
        Element[] tk=new Element[n];
        Element g3=g;
        for (int i = 0; i<n; i++)
        {

            rho[i] = bp.getZr().newRandomElement().getImmutable();
            vPro.setProperty("rho"+i, rho[i].toString());
            tk[i] = rho[i].mulZn(gamma);
            vPro.setProperty("tk"+i, tk[i].toString());
            g3 = g3.powZn(rho[i]);
        }

        Element e = bp.pairing(g,g);
        Element g1 = g.powZn(alpha);
        Element g2 = g.powZn(beta);

        mskProp.setProperty("s1_", Base64.getEncoder().encodeToString(alpha.toBytes()));//element和string类型之间的转换需要通

        //设置公共参数
        //long sta = System.nanoTime();
        //long end = System.nanoTime();
        // out.println(end-sta);
        PProp.setProperty("g1", g1.toString());
        PProp.setProperty("g2", g2.toString());
        PProp.setProperty("g3", g3.toString());
        mskProp.setProperty("alpha",alpha.toString());
        mskProp.setProperty("beta",beta.toString());
        PProp.setProperty("u", u.toString());
        PProp.setProperty("h", h.toString());
        PProp.setProperty("e", e.toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
        storePropToFile(vPro, vectorFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,  String ID,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element eta = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("u");
        Element u = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str=PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        Element ID1 = bp.getZr().newElementFromBytes(ID.getBytes()).getImmutable();
        Element C1 = g1.powZn(s);
        Element C2 = u.powZn(ID1).mulZn(h).powZn(s);
        Element C3 = bp.pairing(g1,g3).powZn(s);
        Element C4 = bp.pairing(g2,g3).powZn(s);
        byte[] ID0 =sha0(ID);
        Element d = bp.getG1().newElementFromHash(ID0,0,ID0.length).getImmutable();
        Element Cx = bp.pairing(bp.getG1().newElementFromHash(ID0,0,ID0.length).getImmutable(),g1).powZn(s);
        Cx = Cx.mulZn(bp.pairing(bp.getG1().newElementFromHash(ID0,0,ID0.length).getImmutable(),g2).powZn(s.mul(eta)));
        Element[] xi = new Element[n];
        for (int i = 0; i < n; i++)
        {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            Cx= Cx.mulZn(bp.pairing(g,g).powZn(xi[i]));
            vPro.setProperty("x"+i,xi[i].toString());
        }

        byte[] C50 =sha0(C1.toString()+C2.toString()+Cx.toString()+C3.toString()+C4.toString()+eta.toString());
        Element C51 = bp.getZr().newElementFromHash(C50,0,C50.length).getImmutable();
        Element s1 = s.mulZn(C51);
        Element C5 = bp.pairing(d,g1).powZn(s1).mulZn(bp.pairing(d,g2).powZn(s));

        randomPro.setProperty("s"+ID, s.toString());
        randomPro.setProperty("uh", u.powZn(ID1).mulZn(h).toString());
        randomPro.setProperty("d", bp.pairing(bp.getG1().newElementFromHash(ID0,0,ID0.length).getImmutable(),g1).toString());
        randomPro.setProperty("eta", eta.toString());
        CTProp.setProperty("C1"+ID, C1.toString());
        CTProp.setProperty("C2"+ID, C2.toString());
        CTProp.setProperty("C3"+ID, C3.toString());
        CTProp.setProperty("Cx"+ID, Cx.toString());
        CTProp.setProperty("C4"+ID, C4.toString());
        CTProp.setProperty("C5"+ID, C5.toString());

        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,String ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        Element r = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("u");
        Element u = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str=PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String alphastr=mskProp.getProperty("alpha");
        Element alpha = bp.getZr().newElementFromBytes(alphastr.getBytes()).getImmutable();
        String betastr=mskProp.getProperty("beta");
        Element beta = bp.getZr().newElementFromBytes(betastr.getBytes()).getImmutable();
        String uhstr=randomProp.getProperty("uh");
        Element uh = bp.getZr().newElementFromBytes(uhstr.getBytes()).getImmutable();
        String dstr=randomProp.getProperty("d");
        Element d = bp.getZr().newElementFromBytes(dstr.getBytes()).getImmutable();
        Element t=bp.getZr().newElementFromBytes(dstr.getBytes()).getImmutable(); ;

        Element  d1 = d.mulZn(g3.powZn(t.invert())).powZn(alpha).mulZn(uh).powZn(r);
        Element  d2 = d.mulZn(g3.powZn(t.invert())).powZn(beta).mul(uh).powZn(r);
        Element  d3 = g.powZn(r.invert());
        Element d4 = t;




        Element[] yi = new Element[n];
        for (int i = 0; i < n; i++) {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            d1 = d1.powZn(yi[i]);
            d2 = d2.powZn(yi[i]);
            vPro.setProperty("y"+i,yi[i].toString());
            skProp.setProperty("y"+i,yi[i].toString());
        }

        skProp.setProperty("d1"+ID,d1.toString());
        skProp.setProperty("d2"+ID,d2.toString());
        skProp.setProperty("d3"+ID,d3.toString());
        skProp.setProperty("d4"+ID,d4.toString());
        randomProp.setProperty("r"+ID,r.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }

    public static void Update(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,String ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        Properties randomProp =loadPropFromFile(randomFile);
        String d1str=skProp.getProperty("d1"+ID);
        String d2str=skProp.getProperty("d2"+ID);
        String d3str=skProp.getProperty("d3"+ID);
        String d4str=skProp.getProperty("d4"+ID);
        Element d1 = bp.getG1().newElementFromBytes(d1str.getBytes()).getImmutable();
        Element d2 = bp.getG1().newElementFromBytes(d2str.getBytes()).getImmutable();
        Element d3 = bp.getG1().newElementFromBytes(d3str.getBytes()).getImmutable();
        Element d4 = bp.getG1().newElementFromBytes(d4str.getBytes()).getImmutable();
        Element r1 = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String uhstr=randomProp.getProperty("uh");
        Element uh = bp.getZr().newElementFromBytes(uhstr.getBytes()).getImmutable();
        Element d11=d1.mulZn(uh).powZn(r1);
        Element d21=d2.mulZn(uh).powZn(r1);
        for (int i = 0; i < n;i++)
        {
            String ystr=skProp.getProperty("y"+i);
            Element y1 = bp.getG1().newElementFromBytes(ystr.getBytes()).getImmutable();
            d11 = d11.powZn(y1);
            d21 = d21.powZn(y1);
        }
        Element d31=d3.mul(g.powZn(r1.invert()));
        skProp.setProperty("d11"+ID,d11.toString());
        skProp.setProperty("d21"+ID,d21.toString());
        skProp.setProperty("d31"+ID,d31.toString());




        storePropToFile(skProp, skFile);


    }



    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String C1str=CTProp.getProperty("C1"+ID);
        Element C1 = bp.getG1().newElementFromBytes(C1str.getBytes()).getImmutable();
        String C2str=CTProp.getProperty("C2"+ID);
        Element C2 = bp.getG1().newElementFromBytes(C2str.getBytes()).getImmutable();
        String C3str=CTProp.getProperty("C3"+ID);
        Element C3 = bp.getG1().newElementFromBytes(C3str.getBytes()).getImmutable();
        String C4str=CTProp.getProperty("C4"+ID);
        Element C4 = bp.getG1().newElementFromBytes(C4str.getBytes()).getImmutable();
        String Cxstr=CTProp.getProperty("Cx"+ID);
        Element Cx = bp.getG1().newElementFromBytes(Cxstr.getBytes()).getImmutable();
        String C5str=CTProp.getProperty("C5"+ID);
        Element C5 = bp.getG1().newElementFromBytes(C5str.getBytes()).getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String sstr=randomProp.getProperty("s");
        Element s = bp.getG1().newElementFromBytes(sstr.getBytes()).getImmutable();
        String d1str=skProp.getProperty("d1"+ID);
        String d2str=skProp.getProperty("d2"+ID);
        String d3str=skProp.getProperty("d3"+ID);
        String d4str=skProp.getProperty("d4"+ID);
        Element d1 = bp.getG1().newElementFromBytes(d1str.getBytes()).getImmutable();
        Element d2 = bp.getG1().newElementFromBytes(d2str.getBytes()).getImmutable();
        Element d3 = bp.getG1().newElementFromBytes(d3str.getBytes()).getImmutable();
        Element d4 = bp.getG1().newElementFromBytes(d4str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str=PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String dstr=randomProp.getProperty("d");
        Element d = bp.getG1().newElementFromBytes(dstr.getBytes()).getImmutable();
        String uhstr=randomProp.getProperty("uh");
        Element uh = bp.getG1().newElementFromBytes(uhstr.getBytes()).getImmutable();
        String etastr=randomProp.getProperty("eta");
        Element eta = bp.getG1().newElementFromBytes(etastr.getBytes()).getImmutable();

        Element[] x = new Element[n];
        Element[] y = new Element[n];
        Element[] y1 = new Element[n];
        Element sy1 = bp.pairing(d,g1).powZn(s);
        Element sy2 = bp.pairing(d,g2).powZn(s.mulZn(eta));
        double sum = 0.0;
        for(int i = 0; i < n; i++)
        {
            String xstr=vPro.getProperty("x"+i);
            String ystr=vPro.getProperty("y"+i);
            sum+=Double.valueOf(xstr)+Double.valueOf(ystr);

            x[i] = bp.getZr().newElementFromBytes(xstr.getBytes()).getImmutable();
            y[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();
            sy1 = sy1.powZn(y[i]);
            sy2 = sy2.powZn(y[i]);
            C3 = C3.powZn(y[i]);
            C4 = C4.powZn(y[i]);

        }
        Element xy = bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable();

        Element C_xy = sy1.mulZn(bp.pairing(g,g.powZn(xy))).mulZn(sy2);
        Element w1 = bp.pairing(C1,d1).mulZn(bp.pairing(C2,d3)).mulZn(C3.powZn(d4));
        Element w2 = bp.pairing(C1,d2).mulZn(bp.pairing(C2,d3)).mulZn(C4.powZn(d4));
        Element XY = C_xy.mulZn(w1.mulZn(w2.powZn(eta)).invert());
        Element EM = bp.pairing(g,g).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (XY.isEqual(EM)) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        long start = System.currentTimeMillis();
        String dir = "./storeFile/Ours_File/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 10;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User1";
        String ID1="User2";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(10)+0;
            y[i] = rand.nextInt(10)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID,n);
        long end3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID1,n);
        System.out.println(end3-start3);
        long start4 = System.currentTimeMillis();
        Update(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID1,n);
        long end4 = System.currentTimeMillis();
        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M,ID);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);
        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }


}
