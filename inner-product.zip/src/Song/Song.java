package Song;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;
import static java.lang.System.setOut;

public class Song {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n,int d) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element[] u = new Element[d+2];
        Element[] h = new Element[n+1];
        for (int i = 1 ; i<=n;i++)
            h[i] = bp.getG1().newRandomElement().getImmutable();
        for (int i = 1; i <= d+1; i++)
            u[i] = bp.getG1().newRandomElement().getImmutable();

        Element  alpha = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数


        Element e = bp.pairing(g,g);
        Element g1 = g.powZn(alpha);


        mskProp.setProperty("msk", Base64.getEncoder().encodeToString(alpha.toBytes()));//element和string类型之间的转换需要通


        //设置公共参数
        //long sta = System.nanoTime();
        //long end = System.nanoTime();
        // out.println(end-sta);
        for (int i = 1; i<=n;i++)
            PProp.setProperty("h"+i, h[i].toString());
        for (int i = 1; i<=d+1;i++)
            PProp.setProperty("u"+i, u[i].toString());
        PProp.setProperty("g1", g1.toString());
        mskProp.setProperty("alpha",alpha.toString());
        PProp.setProperty("e", e.toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);

    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,  String[] ID,int n, double[] x,int d, int l) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);
        Element r = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element[] u = new Element[d+2];
        Element[] h = new Element[n+1];
        for (int i = 1; i <= d+1; i++)
        {
            String ustr=PProp.getProperty("u"+i);
            u[i] = bp.getG1().newElementFromBytes(ustr.getBytes()).getImmutable();
        }
        for (int i = 1; i <= n; i++)
        {
            String hstr=PProp.getProperty("h"+i);
            h[i] = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        }
        Element[] xi = new Element[n];
        Element[] Cxi=new Element[n];
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        for (int i = 0; i < n; i++)
        {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            vPro.setProperty("x"+i,xi[i].toString());
            Cxi[i] = bp.pairing(g,g).powZn(xi[i]).mul(bp.pairing(g1,h[i+1]).powZn(r));
        }

        Element Cr = g.powZn(r);
        Element Cu, u1=u[1].powZn(bp.getG1().newElementFromBytes(ID[0].getBytes()).getImmutable());
        for (int i = 2;i <=l;i++)
            u1 = u1.mulZn(u[i].powZn(bp.getG1().newElementFromBytes(ID[i-1].getBytes()).getImmutable()));
        Cu = u1.mulZn(u[d+1]).powZn(r);
        randomPro.setProperty("r", r.toString());
        for (int i =0; i < n; i++)
            CTProp.setProperty("Cx"+i, Cxi[i].toString());
        CTProp.setProperty("Cr", Cr.toString());
        CTProp.setProperty("Cu", Cu.toString());
        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,int n,int d, String[] ID, int l)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        Element t = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String alphastr=mskProp.getProperty("alpha");
        Element alpha = bp.getZr().newElementFromBytes(alphastr.getBytes()).getImmutable();
        Element[] u = new Element[d+2];
        Element[] h = new Element[n+1];
        for (int i = 1; i <= d+1; i++)
        {
            String ustr=PProp.getProperty("u"+i);
            u[i] = bp.getG1().newElementFromBytes(ustr.getBytes()).getImmutable();
        }
        for (int i = 1; i <= n; i++)
        {
            String hstr=PProp.getProperty("h"+i);
            h[i] = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        }
        Element[] yi = new Element[n];
        for (int i = 0; i < n; i++)
        {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            vPro.setProperty("y"+i,yi[i].toString());
        }
        Element Kh,u1=u[1].powZn(bp.getG1().newElementFromBytes(ID[0].getBytes()).getImmutable()),h1=h[1].powZn(bp.getG1().newElementFromBytes(String.valueOf(y[0]).getBytes()).getImmutable());
        for (int i = 2;i <=d;i++)
            u1 = u1.mulZn(u[i].powZn(bp.getG1().newElementFromBytes(ID[i-1].getBytes()).getImmutable()));
        for (int i = 2;i <= n; i++)
            h1 = h1.mulZn(h[i].powZn(bp.getG1().newElementFromBytes(String.valueOf(y[i-1]).getBytes()).getImmutable()));
        h1 = h1.powZn(alpha);
        u1 = u1.mulZn(u[d+1]).powZn(t.invert());
        Kh = h1.mulZn(u1);
        Element Kt = g.powZn(t);

        for (int i = l+1; i <= d; i++)
        {
            Element Ki = u[i].powZn(t);
            skProp.setProperty("K"+i,Ki.toString());
        }
        skProp.setProperty("Kh",Kh.toString());
        skProp.setProperty("Kt",Kt.toString());


        randomProp.setProperty("t",t.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }

    public static void Delegate(String pairingFile,String paramsFile,String skFile,String randomFile,int n, int d, int l,String[] ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties randomProp =loadPropFromFile(randomFile);
        Element  t1 = bp.getZr().newRandomElement().getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element[] K = new Element[d+1];
        String Khstr=skProp.getProperty("Kh");
        Element Kh = bp.getZr().newElementFromBytes(Khstr.getBytes()).getImmutable();
        String Ktstr=skProp.getProperty("Kt");
        Element Kt = bp.getZr().newElementFromBytes(Ktstr.getBytes()).getImmutable();
        Element Kt1=Kt.mulZn(g.powZn(t1));
        Element[] u = new Element[d+2];
        for (int i = 1; i <= d+1; i++)
        {
            String ustr=PProp.getProperty("u"+i);
            u[i] = bp.getG1().newElementFromBytes(ustr.getBytes()).getImmutable();
        }

        for (int i = l+1; i <= d; i++)
        {
            String kh=skProp.getProperty("K"+i);
            K[i] = bp.getG1().newElementFromBytes(kh.getBytes()).getImmutable();
        }
        Element u1=u[1].powZn(bp.getG1().newElementFromBytes(ID[0].getBytes()).getImmutable());
        for (int i = 2;i <=d;i++)
            u1 = u1.mulZn(u[i].powZn(bp.getG1().newElementFromBytes(ID[i-1].getBytes()).getImmutable()));
        u1 = u1.mulZn(u[d+1]).powZn(t1.invert());
        Element Kh1=Kh.mulZn(K[l+1].powZn(bp.getZr().newElementFromBytes(ID[l].getBytes()).getImmutable().invert())).mulZn(u1).getImmutable();

        for (int i = l+2; i <= d; i++)
        {
            Element Ki = K[i].mulZn(u[i].powZn(t1));
            skProp.setProperty("K"+i,Ki.toString());
        }
        skProp.setProperty("Kh",Kh1.toString());
        skProp.setProperty("Kt",Kt1.toString());


        randomProp.setProperty("t1",t1.toString());



        storePropToFile(randomProp,randomFile);

        storePropToFile(skProp, skFile);


    }


    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,int l, int d, String[] ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);

        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element[] u = new Element[d+2];
        Element[] h = new Element[n+1];
        for (int i = 1; i <= d+1; i++)
        {
            String ustr=PProp.getProperty("u"+i);
            u[i] = bp.getG1().newElementFromBytes(ustr.getBytes()).getImmutable();
        }
        for (int i = 1; i <= n; i++)
        {
            String hstr=PProp.getProperty("h"+i);
            h[i] = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        }
        String rstr = randomProp.getProperty("r");
        Element r = bp.getZr().newElementFromBytes(rstr.getBytes()).getImmutable();


        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();




        Element[] x = new Element[n];
        Element[] y = new Element[n];
        double sum = 0.0;
        for(int i = 0; i < n; i++)
        {
            String xstr=vPro.getProperty("x"+i);
            String ystr=vPro.getProperty("y"+i);

            sum+=Double.valueOf(xstr)+Double.valueOf(ystr);

            x[i] = bp.getZr().newElementFromBytes(xstr.getBytes()).getImmutable();
            y[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();

        }
        Element xy = bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable();
        Element Cxi=bp.pairing(g,g).powZn(xy).getImmutable();
        for(int i = 1; i <= n; i++)
            Cxi=Cxi.mul(bp.pairing(g1,h[i]).powZn(r.mulZn(y[i-1])));
        String Crstr = CTProp.getProperty("Cr");
        String Khstr = skProp.getProperty("Kh");
        String Ktstr = skProp.getProperty("Kt");
        String Custr = CTProp.getProperty("Cu");
        Element Cr = bp.getG1().newElementFromBytes(Crstr.getBytes()).getImmutable();
        Element Kh = bp.getG1().newElementFromBytes(Khstr.getBytes()).getImmutable();
        Element Kt = bp.getG1().newElementFromBytes(Ktstr.getBytes()).getImmutable();
        Element Cu = bp.getG1().newElementFromBytes(Custr.getBytes()).getImmutable();
        Element XY = Cxi.div(bp.pairing(Cr,Kh)).div(bp.pairing(Cu,Kt));
        Element EM = bp.pairing(g,g).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (XY.isEqual(EM)) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static String getRandomString(int length) {

        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        Random random = new Random();

        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < length; i++) {

            int number = random.nextInt(62);    //从62个字符中随机取其中一个

            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

        }

        return sb.toString();  //返回字符串

    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        long start = System.currentTimeMillis();
        String dir = "./storeFile/Song_File/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 50;
        int d=10,l=3;
        double[] x = new double[n];
        double[] y = new double[n];
        String[] ID= new String[n];
        for (int i = 0; i <n;i++)
            ID[i] = getRandomString(10);
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(20)+0;
            y[i] = rand.nextInt(20)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n,d);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x,d,l);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,n,d,ID,l);
        long end3 = System.currentTimeMillis();
        System.out.println(end3-start3);
        long start4 = System.currentTimeMillis();
        Delegate(pairingParametersFileName,ParameterFileName,skFileName,randomFileName,n,d,l,ID);
        long end4 = System.currentTimeMillis();
        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M,l,d,ID);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);
        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }


}
